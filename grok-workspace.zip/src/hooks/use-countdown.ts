import { useEffect, useRef, useState } from "react";
import { birthday } from "@/config/birthday";
import {
  atmosphereFromRemaining,
  getTargetMs,
  splitRemaining,
  type Atmosphere,
  type RemainingParts,
} from "@/lib/ist-time";

export type CountdownState = RemainingParts & {
  atmosphere: Atmosphere;
  targetMs: number;
  now: number;
};

export function useCountdown(fakeRemainingMs: number | null = null): CountdownState {
  const [now, setNow] = useState(() => Date.now());
  const fake = useRef<{ origin: number; remaining: number } | null>(null);

  useEffect(() => {
    if (fakeRemainingMs == null) {
      fake.current = null;
      return;
    }
    fake.current = { origin: Date.now(), remaining: fakeRemainingMs };
    setNow(Date.now());
  }, [fakeRemainingMs]);

  useEffect(() => {
    let timeout = 0;
    const tick = () => {
      setNow(Date.now());
      timeout = window.setTimeout(tick, 250);
    };
    tick();
    const refresh = () => setNow(Date.now());
    document.addEventListener("visibilitychange", refresh);
    window.addEventListener("focus", refresh);
    window.addEventListener("pageshow", refresh);
    return () => {
      window.clearTimeout(timeout);
      document.removeEventListener("visibilitychange", refresh);
      window.removeEventListener("focus", refresh);
      window.removeEventListener("pageshow", refresh);
    };
  }, []);

  const targetMs = getTargetMs(birthday.target);
  const remainingMs = fake.current
    ? fake.current.remaining - (now - fake.current.origin)
    : targetMs - now;
  const parts = splitRemaining(remainingMs);

  return {
    ...parts,
    atmosphere: atmosphereFromRemaining(remainingMs),
    targetMs,
    now,
  };
}
