import { createFileRoute } from "@tanstack/react-router";
import { BirthdayWorld } from "@/components/experience/BirthdayWorld";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <BirthdayWorld />;
}
