import type { BirthdayTarget } from "@/lib/ist-time";

export const birthday = {
  name: "Srijoni",
  target: {
    year: 2026,
    month: 9,
    day: 30,
    hour: 0,
    minute: 0,
    second: 0,
  } satisfies BirthdayTarget,
  monthsTogether: 7,
} as const;

export type Photo = {
  src: string;
  alt: string;
  caption?: string;
  objectPosition?: string;
};

/**
 * Add a photograph by appending an entry. The waiting world and the
 * memory chapters pick up whatever is in this list automatically.
 */
export const photos: Photo[] = [
  {
    src: "/photos/saree-stairs.webp",
    alt: "Srijoni sitting on marble stairs in a gold saree",
    objectPosition: "center 18%",
  },
  {
    src: "/photos/portrait-sweater.webp",
    alt: "Srijoni looking into the camera",
    objectPosition: "center 15%",
  },
  {
    src: "/photos/flower-hair.webp",
    alt: "Srijoni with a pink flower in her hair",
    objectPosition: "center 20%",
  },
  {
    src: "/photos/kurta-selfie.webp",
    alt: "Srijoni taking a mirror photograph",
    objectPosition: "center 20%",
  },
  {
    src: "/photos/lipstick-mirror.webp",
    alt: "Srijoni in a red top at a bathroom mirror",
    objectPosition: "center 40%",
  },
  {
    src: "/photos/covering-smile.webp",
    alt: "Srijoni covering part of her face, smiling",
    objectPosition: "center 35%",
  },
  {
    src: "/photos/closeup-dots.webp",
    alt: "Close portrait of Srijoni",
    objectPosition: "center 30%",
  },
  {
    src: "/photos/mirror-white.webp",
    alt: "Srijoni in a white embroidered dress",
    objectPosition: "center 25%",
  },
  {
    src: "/photos/pink-squint.webp",
    alt: "Srijoni squinting, laughing",
    objectPosition: "center 20%",
  },
  {
    src: "/photos/anime-glance.webp",
    alt: "An illustration of a girl looking down",
    objectPosition: "center 30%",
  },
  {
    src: "/photos/bunny-plush.webp",
    alt: "A worn pink plush bunny",
    objectPosition: "center 40%",
  },
];

export type GardenSprite = {
  src: string;
  x: string;
  y: string;
  w: string;
  rotate: number;
  delay: number;
  duration: number;
  mobile?: boolean;
  blend?: "lighten" | "normal";
  opacity?: number;
};

export const flowers: GardenSprite[] = [
  {
    src: "/garden/rose-ivory.webp",
    x: "-8%",
    y: "58%",
    w: "13.5rem",
    rotate: -18,
    delay: 0,
    duration: 11,
    mobile: true,
    blend: "lighten",
    opacity: 0.88,
  },
  {
    src: "/garden/peony-blush.webp",
    x: "72%",
    y: "-4%",
    w: "11rem",
    rotate: 14,
    delay: 1.2,
    duration: 13,
    mobile: true,
    blend: "lighten",
    opacity: 0.8,
  },
  {
    src: "/garden/rose-burgundy.webp",
    x: "78%",
    y: "62%",
    w: "10.5rem",
    rotate: 8,
    delay: 0.6,
    duration: 12,
    mobile: true,
    blend: "lighten",
    opacity: 0.78,
  },
  {
    src: "/garden/jasmine.webp",
    x: "-2%",
    y: "6%",
    w: "9.5rem",
    rotate: -8,
    delay: 1.8,
    duration: 14,
    mobile: false,
    blend: "lighten",
    opacity: 0.7,
  },
  {
    src: "/garden/rose-stem.webp",
    x: "38%",
    y: "78%",
    w: "8rem",
    rotate: 22,
    delay: 2.4,
    duration: 16,
    mobile: false,
    blend: "lighten",
    opacity: 0.55,
  },
  {
    src: "/garden/peony-blush.webp",
    x: "8%",
    y: "78%",
    w: "7.5rem",
    rotate: -28,
    delay: 3,
    duration: 15,
    mobile: false,
    blend: "lighten",
    opacity: 0.5,
  },
];

export const teddies: GardenSprite[] = [
  {
    src: "/garden/teddy-mocha.webp",
    x: "-4%",
    y: "70%",
    w: "8.5rem",
    rotate: -6,
    delay: 0.4,
    duration: 6.5,
    mobile: true,
    blend: "normal",
    opacity: 0.92,
  },
  {
    src: "/garden/teddy-rose.webp",
    x: "76%",
    y: "72%",
    w: "7.8rem",
    rotate: 8,
    delay: 1.1,
    duration: 7.4,
    mobile: true,
    blend: "normal",
    opacity: 0.9,
  },
];

export const cake = {
  theme: "midnight-garden",
  src: "/garden/cake-whole.webp",
  cutSrc: "/garden/cake-cut.webp",
  canCut: true,
  wish: "Make a wish.",
} as const;

export const openingLines = {
  waiting: ["Hey, Srijoni.", "I made you something.", "Stay until the clock reaches zero."],
  alreadyHere: ["Hey, Srijoni.", "It's already your day."],
} as const;

export const waitingLine =
  "I couldn't be there when the clock turns to your birthday, so I built a little world that waits with you until it does.";

export const personalMessage = [
  "I wanted to be in the room when the date changed.",
  "I couldn't. Distance gets a say in the furniture. It doesn't get a say in the day.",
  "So I stayed up with a clock instead, and I built you a place to wait inside.",
];

export const letter = {
  greeting: "Srijoni,",
  body: [
    "I couldn't be there when the clock turns.",
    "There's a version of tonight where I'm in the same room — watching the numbers become a date, saying the thing out loud instead of building a place to hold it. That version isn't this one. Distance decided that. I didn't.",
    "So I made this. A small world that waits the way I would have waited. Dark at first. Then flowers. Then your face, again and again, because that's the part I keep.",
    "Seven months of us, and I still look at the same photographs like they might tell me something new. They don't have to. They're already enough.",
    "I keep thinking of midnight as a kind of meeting place. You on one side of it. Me on the other. The same second, just not the same floor. Clocks are honest like that. They don't care who is missing from the room. They just keep going until the day belongs to you.",
    "I wish I could hand you something with weight. A flower that isn't made of light. A cake that actually takes up space on a table. The ordinary, clumsy, physical kind of birthday.",
    "This is the closest I could get from here.",
    "You matter to me in the quiet way — the way that doesn't need an audience. These seven months aren't a preview of something. They're already the thing. I don't know when the road between us gets shorter. I just know I want to be on it when it does.",
    "Until then: I hope this night feels like it was kept for you.",
  ],
  signoff: "Happy Birthday, Srijoni.",
  closing: "still here. still yours. still counting.",
} as const;

export const finale = {
  title: "Happy Birthday, Srijoni.",
  subtitle: "Seven months of us.",
  line: "Some distances are just time that hasn't finished walking yet.",
} as const;
