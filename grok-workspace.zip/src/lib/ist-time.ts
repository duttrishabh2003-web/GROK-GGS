/**
 * Birthday midnight in Asia/Kolkata (IST, UTC+5:30).
 * India does not observe daylight saving — the offset is fixed.
 * Remaining time is always derived from timestamps, never decremented.
 */

export const IST_OFFSET = "+05:30";
export const TARGET_TIME_ZONE = "Asia/Kolkata";

export type BirthdayTarget = {
  year: number;
  month: number;
  day: number;
  hour?: number;
  minute?: number;
  second?: number;
};

export function pad2(n: number): string {
  return n.toString().padStart(2, "0");
}

export function targetIso(t: BirthdayTarget): string {
  const hour = t.hour ?? 0;
  const minute = t.minute ?? 0;
  const second = t.second ?? 0;
  return `${t.year}-${pad2(t.month)}-${pad2(t.day)}T${pad2(hour)}:${pad2(minute)}:${pad2(second)}${IST_OFFSET}`;
}

export function getTargetMs(t: BirthdayTarget): number {
  return Date.parse(targetIso(t));
}

export type RemainingParts = {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  totalSeconds: number;
  remainingMs: number;
  isZero: boolean;
};

export function splitRemaining(ms: number): RemainingParts {
  const remainingMs = Math.max(0, ms);
  const totalSeconds = Math.floor(remainingMs / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return {
    days,
    hours,
    minutes,
    seconds,
    totalSeconds,
    remainingMs,
    isZero: ms <= 0,
  };
}

export type AtmosphereLevel =
  | "calm"
  | "hour"
  | "halfhour"
  | "tenmin"
  | "minute"
  | "final10"
  | "zero";

export type Atmosphere = {
  level: AtmosphereLevel;
  warmth: number;
  motion: number;
  photoCount: number;
};

export function atmosphereFromRemaining(ms: number): Atmosphere {
  if (ms <= 0) return { level: "zero", warmth: 1, motion: 0.5, photoCount: 6 };
  const minutes = ms / 60_000;
  const hours = ms / 3_600_000;
  const seconds = ms / 1000;
  if (seconds <= 10) return { level: "final10", warmth: 0.9, motion: 0.12, photoCount: 0 };
  if (minutes <= 1) return { level: "minute", warmth: 0.82, motion: 0.92, photoCount: 3 };
  if (minutes <= 10) return { level: "tenmin", warmth: 0.68, motion: 0.78, photoCount: 2 };
  if (minutes <= 30) return { level: "halfhour", warmth: 0.52, motion: 0.62, photoCount: 2 };
  if (hours <= 1) return { level: "hour", warmth: 0.4, motion: 0.5, photoCount: 1 };
  return { level: "calm", warmth: 0.22, motion: 0.34, photoCount: 1 };
}
