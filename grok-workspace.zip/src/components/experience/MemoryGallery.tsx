import type { CSSProperties } from "react";
import { photos } from "@/config/birthday";
import { cn } from "@/lib/utils";

function Frame({
  src,
  alt,
  objectPosition,
  className,
  rotate = 0,
  style,
}: {
  src: string;
  alt: string;
  objectPosition?: string;
  className?: string;
  rotate?: number;
  style?: CSSProperties;
}) {
  return (
    <figure
      className={cn("overflow-hidden bg-ivory p-1.5 shadow-[0_20px_50px_rgba(0,0,0,0.45)]", className)}
      style={{ transform: `rotate(${rotate}deg)`, ...style }}
    >
      <img
        src={src}
        alt={alt}
        className="h-full w-full object-cover"
        style={{ objectPosition: objectPosition ?? "center" }}
        loading="lazy"
        draggable={false}
      />
    </figure>
  );
}

export function MemoryGallery() {
  const saree = photos[0];
  const portrait = photos[1];
  const flowerHair = photos[2];
  const kurta = photos[3];
  const lipstick = photos[4];
  const covering = photos[5];
  const closeup = photos[6];
  const whiteDress = photos[7];
  const squint = photos[8];
  const bunny = photos[10];

  return (
    <div className="relative">
      <section className="relative flex min-h-[100dvh] flex-col justify-center px-5 py-16 md:px-16">
        <p className="mb-8 text-center text-[0.65rem] tracking-[0.42em] text-champagne uppercase">
          this light
        </p>
        <div className="mx-auto flex w-full max-w-3xl flex-col items-center gap-8 md:flex-row md:items-end md:justify-center">
          <Frame
            src={saree.src}
            alt={saree.alt}
            objectPosition={saree.objectPosition}
            className="h-[62vw] w-[78%] max-h-[28rem] max-w-sm md:h-[28rem] md:w-[22rem]"
            rotate={-2.5}
          />
          <Frame
            src={portrait.src}
            alt={portrait.alt}
            objectPosition={portrait.objectPosition}
            className="h-44 w-36 md:h-56 md:w-44"
            rotate={7}
          />
        </div>
      </section>

      <section className="relative flex min-h-[100dvh] flex-col justify-center px-5 py-16 md:px-16">
        <p className="mb-8 text-center text-[0.65rem] tracking-[0.42em] text-champagne uppercase">
          the rooms you occupy
        </p>
        <div className="mx-auto grid w-full max-w-3xl grid-cols-2 gap-4 md:gap-8">
          <Frame
            src={flowerHair.src}
            alt={flowerHair.alt}
            objectPosition={flowerHair.objectPosition}
            className="aspect-[4/5] w-full"
            rotate={-4}
          />
          <Frame
            src={kurta.src}
            alt={kurta.alt}
            objectPosition={kurta.objectPosition}
            className="mt-10 aspect-[4/5] w-full"
            rotate={5}
          />
          <Frame
            src={lipstick.src}
            alt={lipstick.alt}
            objectPosition={lipstick.objectPosition}
            className="col-span-2 mx-auto mt-2 aspect-[4/5] w-44 md:w-56"
            rotate={-3}
          />
        </div>
      </section>

      <section className="relative flex min-h-[100dvh] flex-col justify-center px-5 py-16 md:px-16">
        <p className="mb-8 text-center text-[0.65rem] tracking-[0.42em] text-champagne uppercase">
          closer
        </p>
        <div className="mx-auto flex w-full max-w-3xl flex-col items-center gap-8 md:flex-row md:items-center md:justify-center">
          <Frame
            src={covering.src}
            alt={covering.alt}
            objectPosition={covering.objectPosition}
            className="h-[58vw] w-[76%] max-h-[26rem] max-w-sm md:h-[26rem] md:w-[20rem]"
            rotate={2}
          />
          <Frame
            src={closeup.src}
            alt={closeup.alt}
            objectPosition={closeup.objectPosition}
            className="h-48 w-56 md:h-52 md:w-64"
            rotate={-6}
          />
        </div>
      </section>

      <section className="relative flex min-h-[100dvh] flex-col justify-center px-5 py-16 md:px-16">
        <p className="mb-8 text-center text-[0.65rem] tracking-[0.42em] text-champagne uppercase">
          and this
        </p>
        <div className="relative mx-auto h-[30rem] w-full max-w-md">
          <Frame
            src={whiteDress.src}
            alt={whiteDress.alt}
            objectPosition={whiteDress.objectPosition}
            className="absolute top-4 left-2 aspect-[3/5] w-40 md:w-48"
            rotate={-8}
          />
          <Frame
            src={squint.src}
            alt={squint.alt}
            objectPosition={squint.objectPosition}
            className="absolute top-24 right-2 aspect-[4/5] w-40 md:w-48"
            rotate={6}
          />
          <Frame
            src={bunny.src}
            alt={bunny.alt}
            objectPosition={bunny.objectPosition}
            className="absolute bottom-2 left-1/4 aspect-[3/5] w-32 md:w-40"
            rotate={-2}
          />
        </div>
      </section>
    </div>
  );
}
