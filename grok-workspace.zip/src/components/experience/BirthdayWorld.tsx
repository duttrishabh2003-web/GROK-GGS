import { useEffect, useMemo, useState } from "react";
import { waitingLine } from "@/config/birthday";
import { useCountdown } from "@/hooks/use-countdown";
import { useLenis } from "@/hooks/use-lenis";
import { usePrefersReducedMotion } from "@/hooks/use-prefers-reduced-motion";
import { BirthdayTransition } from "@/components/experience/BirthdayTransition";
import { CakeScene } from "@/components/experience/CakeScene";
import { CountdownClock } from "@/components/experience/CountdownClock";
import { FinalScene } from "@/components/experience/FinalScene";
import { FinalTen } from "@/components/experience/FinalTen";
import { FlowerField } from "@/components/experience/FlowerField";
import { MemoryGallery } from "@/components/experience/MemoryGallery";
import { OpeningScene } from "@/components/experience/OpeningScene";
import { ParticleField } from "@/components/experience/ParticleField";
import { PhotoMemory } from "@/components/experience/PhotoMemory";
import { PoeticLetter } from "@/components/experience/PoeticLetter";
import { TeddyBear } from "@/components/experience/TeddyBear";
import { cn } from "@/lib/utils";

type Phase = "opening" | "waiting" | "final10" | "zero" | "world";
type Preview = Phase | null;

function readPreview(): Preview {
  if (typeof window === "undefined") return null;
  const value = new URLSearchParams(window.location.search).get("preview");
  if (
    value === "opening" ||
    value === "waiting" ||
    value === "final10" ||
    value === "zero" ||
    value === "world"
  ) {
    return value;
  }
  return null;
}

export function BirthdayWorld() {
  const reduced = usePrefersReducedMotion();
  const [mounted, setMounted] = useState(false);
  const [preview, setPreview] = useState<Preview>(null);
  const [phase, setPhase] = useState<Phase>("opening");
  const [lineVisible, setLineVisible] = useState(true);

  const fakeRemainingMs = useMemo(() => {
    if (preview === "final10") return 10_500;
    if (preview === "waiting") return 6 * 60 * 60 * 1000 + 41 * 60 * 1000;
    return null;
  }, [preview]);

  const clock = useCountdown(fakeRemainingMs);
  useLenis(phase === "world");

  useEffect(() => {
    setMounted(true);
    const next = readPreview();
    setPreview(next);
    if (next === "world") setPhase("world");
    if (next === "zero") setPhase("zero");
    if (next === "waiting") setPhase("waiting");
    if (next === "final10") setPhase("final10");
  }, []);

  useEffect(() => {
    if (preview === "waiting" || preview === "opening") return;
    if (phase === "opening" || phase === "zero" || phase === "world") return;
    if (clock.isZero) {
      setPhase("zero");
      return;
    }
    if (clock.totalSeconds <= 10 && phase === "waiting") {
      setPhase("final10");
    }
  }, [clock.isZero, clock.totalSeconds, phase, preview]);

  useEffect(() => {
    if (phase !== "waiting") return;
    const id = window.setTimeout(() => setLineVisible(false), 14_000);
    return () => window.clearTimeout(id);
  }, [phase]);

  const locked = phase !== "world";

  if (!mounted) {
    return <main className="h-[100dvh] bg-void" aria-label="For Srijoni" />;
  }

  const onOpeningDone = () => {
    if (preview === "opening") {
      setPhase("waiting");
      return;
    }
    if (preview === "final10") {
      setPhase("final10");
      return;
    }
    if (clock.isZero) setPhase("zero");
    else if (clock.totalSeconds <= 10) setPhase("final10");
    else setPhase("waiting");
  };

  return (
    <main
      className={cn(
        "relative bg-void text-ivory",
        locked ? "h-[100dvh] overflow-hidden" : "min-h-[100dvh] overflow-x-hidden",
      )}
      style={{
        paddingTop: "env(safe-area-inset-top)",
        paddingBottom: "env(safe-area-inset-bottom)",
      }}
    >
      {phase === "opening" ? (
        <OpeningScene
          alreadyHere={clock.isZero && preview !== "waiting" && preview !== "opening"}
          reduced={reduced}
          onComplete={onOpeningDone}
        />
      ) : null}

      {phase === "waiting" || phase === "final10" ? (
        <div className="absolute inset-0">
          <div
            className="absolute inset-0 transition-[background] duration-1000"
            style={{
              background: `radial-gradient(ellipse at 50% 42%, rgba(232, 201, 160, ${0.04 + clock.atmosphere.warmth * 0.12}) 0%, transparent 55%)`,
            }}
          />
          <ParticleField
            density={48 + Math.round(clock.atmosphere.warmth * 40)}
            warmth={clock.atmosphere.warmth}
            reduced={reduced}
          />
          <FlowerField
            motion={clock.atmosphere.motion}
            extra={clock.atmosphere.level === "minute" || clock.atmosphere.level === "tenmin"}
            reduced={reduced}
          />
          <TeddyBear motion={clock.atmosphere.motion} reduced={reduced} />
          <PhotoMemory
            count={clock.atmosphere.photoCount}
            reduced={reduced}
            freeze={phase === "final10"}
          />
          <div className="vignette absolute inset-0" />
          {phase === "waiting" ? (
            <div className="relative z-10 flex h-full flex-col items-center justify-center">
              <CountdownClock
                days={clock.days}
                hours={clock.hours}
                minutes={clock.minutes}
                seconds={clock.seconds}
                line={lineVisible ? waitingLine : undefined}
              />
            </div>
          ) : (
            <FinalTen seconds={clock.seconds} reduced={reduced} />
          )}
        </div>
      ) : null}

      {phase === "zero" ? (
        <BirthdayTransition reduced={reduced} onComplete={() => setPhase("world")} />
      ) : null}

      {phase === "world" ? (
        <div className="relative">
          <ParticleField density={36} warmth={0.45} reduced={reduced} />
          <FlowerField motion={0.4} extra reduced={reduced} />
          <div className="grain absolute inset-0 z-20 h-full" />
          <header className="relative z-10 flex min-h-[100dvh] flex-col items-center justify-center px-6">
            <p className="mb-6 text-[0.65rem] tracking-[0.42em] text-champagne uppercase">
              September 30
            </p>
            <h1 className="font-display max-w-sm text-center text-4xl text-ivory italic sm:text-5xl">
              Happy Birthday, Srijoni.
            </h1>
            <p className="mt-8 text-sm tracking-[0.22em] text-muted">scroll when you're ready</p>
          </header>
          <div className="relative z-10">
            <MemoryGallery />
            <PoeticLetter />
            <CakeScene />
            <FinalScene />
          </div>
        </div>
      ) : null}

      <div className="grain pointer-events-none fixed inset-0 z-30" />
    </main>
  );
}
