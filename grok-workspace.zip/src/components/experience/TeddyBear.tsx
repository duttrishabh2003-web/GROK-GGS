import { teddies, type GardenSprite } from "@/config/birthday";
import { cn } from "@/lib/utils";

type Props = {
  motion?: number;
  className?: string;
  reduced?: boolean;
  celebrate?: boolean;
};

function Bear({
  bear,
  reduced,
  celebrate,
}: {
  bear: GardenSprite;
  reduced: boolean;
  celebrate: boolean;
}) {
  return (
    <img
      src={bear.src}
      alt=""
      className={cn(
        "pointer-events-none absolute select-none drop-shadow-[0_18px_30px_rgba(0,0,0,0.55)]",
        !bear.mobile && "hidden md:block",
        !reduced && "breathe",
      )}
      style={{
        left: celebrate ? (bear.x.startsWith("-") ? "8%" : "70%") : bear.x,
        top: celebrate ? "58%" : bear.y,
        width: bear.w,
        opacity: bear.opacity ?? 0.9,
        mixBlendMode: "normal",
        ["--r" as string]: `${bear.rotate}deg`,
        ["--dur" as string]: `${bear.duration}s`,
        ["--delay" as string]: `${bear.delay}s`,
        transition: "left 1.6s cubic-bezier(0.22, 1, 0.36, 1), top 1.6s cubic-bezier(0.22, 1, 0.36, 1)",
      }}
      draggable={false}
    />
  );
}

export function TeddyBear({ motion = 0.35, className, reduced = false, celebrate = false }: Props) {
  void motion;
  return (
    <div className={cn("pointer-events-none absolute inset-0 overflow-hidden", className)} aria-hidden>
      {teddies.map((bear, i) => (
        <Bear key={`${bear.src}-${i}`} bear={bear} reduced={reduced} celebrate={celebrate} />
      ))}
    </div>
  );
}
