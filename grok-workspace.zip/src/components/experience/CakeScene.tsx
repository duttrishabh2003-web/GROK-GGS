import { useState } from "react";
import { cake } from "@/config/birthday";
import { cn } from "@/lib/utils";

export function CakeScene() {
  const [cut, setCut] = useState(false);

  return (
    <section className="relative flex min-h-[100dvh] flex-col items-center justify-center px-6 py-24">
      <p className="mb-3 text-[0.65rem] tracking-[0.42em] text-champagne uppercase">
        {cake.theme.replace("-", " ")}
      </p>
      <p className="font-display mb-10 text-center text-2xl text-ivory italic">{cake.wish}</p>
      <button
        type="button"
        disabled={!cake.canCut}
        onClick={() => setCut(true)}
        className="group relative max-w-sm transition-transform duration-150 ease-out active:scale-[0.96]"
        aria-label={cut ? "Birthday cake" : "Tap the cake"}
      >
        <img
          src={cake.src}
          alt="Ivory birthday cake with flowers and gold candles"
          className={cn(
            "w-[min(86vw,22rem)] transition-opacity duration-700",
            cut ? "opacity-0" : "opacity-100",
          )}
          draggable={false}
        />
        <img
          src={cake.cutSrc}
          alt=""
          className={cn(
            "absolute inset-0 w-[min(86vw,22rem)] transition-opacity duration-700",
            cut ? "opacity-100" : "opacity-0",
          )}
          draggable={false}
        />
        <span
          className="pointer-events-none absolute inset-x-12 top-8 h-16 rounded-full bg-candle/20 blur-2xl"
          aria-hidden
        />
      </button>
      <p className="mt-8 min-h-6 text-center text-sm tracking-[0.16em] text-muted">
        {cake.canCut ? (cut ? "that's yours." : "tap the cake.") : null}
      </p>
    </section>
  );
}
