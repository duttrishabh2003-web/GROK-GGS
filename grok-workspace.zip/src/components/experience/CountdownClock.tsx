import { useLayoutEffect, useRef } from "react";
import gsap from "gsap";
import { pad2 } from "@/lib/ist-time";
import { cn } from "@/lib/utils";

type Props = {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  line?: string;
  compact?: boolean;
  className?: string;
};

function TickNumber({ value, className }: { value: string; className?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const prev = useRef(value);

  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (prev.current === value) return;
    prev.current = value;
    gsap.fromTo(
      el,
      { y: 10, opacity: 0.35, filter: "blur(5px)" },
      { y: 0, opacity: 1, filter: "blur(0px)", duration: 0.38, ease: "power2.out" },
    );
  }, [value]);

  return (
    <span ref={ref} className={cn("inline-block tabular-nums", className)}>
      {value}
    </span>
  );
}

function Unit({
  value,
  label,
  large,
}: {
  value: number;
  label: string;
  large?: boolean;
}) {
  return (
    <div className="flex min-w-0 flex-col items-center gap-1.5">
      <TickNumber
        value={pad2(value)}
        className={cn(
          "font-light tracking-tight text-ivory",
          large ? "text-5xl sm:text-6xl md:text-7xl" : "text-4xl sm:text-5xl md:text-6xl",
        )}
      />
      <span className="text-[0.62rem] font-normal tracking-[0.38em] text-champagne/80 uppercase sm:text-xs">
        {label}
      </span>
    </div>
  );
}

export function CountdownClock({
  days,
  hours,
  minutes,
  seconds,
  line,
  compact = false,
  className,
}: Props) {
  return (
    <div className={cn("relative z-10 flex flex-col items-center px-4", className)}>
      <p className="mb-8 text-[0.65rem] tracking-[0.42em] text-muted uppercase">
        IST · midnight
      </p>
      <div
        className={cn(
          "grid w-full max-w-lg grid-cols-4 items-end",
          compact ? "gap-3 sm:gap-6" : "gap-4 sm:gap-8",
        )}
      >
        <Unit value={days} label="Days" />
        <Unit value={hours} label="Hours" large />
        <Unit value={minutes} label="Minutes" large />
        <Unit value={seconds} label="Seconds" />
      </div>
      {line ? (
        <p className="font-display mt-10 max-w-sm text-center text-base leading-relaxed text-ivory-dim italic sm:text-lg">
          {line}
        </p>
      ) : null}
    </div>
  );
}
