import { letter, personalMessage } from "@/config/birthday";

export function PoeticLetter() {
  return (
    <>
      <section className="relative mx-auto flex min-h-[100dvh] max-w-lg flex-col justify-center px-6 py-24">
        <p className="mb-10 text-center text-[0.65rem] tracking-[0.42em] text-champagne uppercase">
          a note
        </p>
        <div className="space-y-8">
          {personalMessage.map((line) => (
            <p
              key={line}
              className="font-display text-center text-2xl leading-snug text-ivory italic sm:text-3xl"
            >
              {line}
            </p>
          ))}
        </div>
      </section>

      <section className="relative mx-auto flex min-h-[100dvh] max-w-xl flex-col justify-center px-6 py-28">
        <p className="font-display mb-10 text-2xl text-ivory italic">{letter.greeting}</p>
        <div className="space-y-7">
          {letter.body.map((para) => (
            <p key={para} className="text-[1.05rem] leading-[1.75] text-ivory-dim">
              {para}
            </p>
          ))}
        </div>
        <p className="font-display mt-14 text-2xl text-ivory italic">{letter.signoff}</p>
        <p className="mt-6 text-sm tracking-[0.18em] text-muted">{letter.closing}</p>
      </section>
    </>
  );
}
