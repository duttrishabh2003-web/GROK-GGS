import { useEffect, useMemo, useState, type CSSProperties } from "react";
import { photos, type Photo } from "@/config/birthday";
import { cn } from "@/lib/utils";

const SLOTS = [
  { top: "7%", left: "4%", rotate: -9, width: "7.4rem" },
  { top: "10%", right: "3%", rotate: 8, width: "6.8rem" },
  { bottom: "16%", left: "3%", rotate: -6, width: "7.6rem" },
  { bottom: "18%", right: "4%", rotate: 7, width: "7.1rem" },
] as const;

type Props = {
  count?: number;
  className?: string;
  reduced?: boolean;
  freeze?: boolean;
};

function Polaroid({
  photo,
  slot,
}: {
  photo: Photo;
  slot: (typeof SLOTS)[number];
}) {
  const pos: CSSProperties = {
    width: slot.width,
    transform: `rotate(${slot.rotate}deg)`,
    ...("left" in slot ? { left: slot.left } : { right: slot.right }),
    ...("top" in slot ? { top: slot.top } : { bottom: slot.bottom }),
  };
  return (
    <figure
      className="absolute bg-ivory p-1.5 pb-6 shadow-[0_18px_40px_rgba(0,0,0,0.45)] bloom-in"
      style={pos}
    >
      <div className="aspect-[4/5] overflow-hidden bg-charcoal">
        <img
          src={photo.src}
          alt={photo.alt}
          className="h-full w-full object-cover"
          style={{ objectPosition: photo.objectPosition ?? "center" }}
          draggable={false}
        />
      </div>
      {photo.caption ? (
        <figcaption className="font-display mt-1.5 px-0.5 text-center text-[0.65rem] italic text-charcoal/80">
          {photo.caption}
        </figcaption>
      ) : null}
    </figure>
  );
}

export function PhotoMemory({ count = 1, className, reduced = false, freeze = false }: Props) {
  const [tick, setTick] = useState(0);
  const list = photos.filter((p) => !p.src.includes("bunny") && !p.src.includes("anime"));

  useEffect(() => {
    if (freeze || reduced) return;
    const id = window.setInterval(() => setTick((n) => n + 1), 7800);
    return () => window.clearInterval(id);
  }, [freeze, reduced]);

  const visible = useMemo(() => {
    const n = Math.max(0, Math.min(count, SLOTS.length));
    return Array.from({ length: n }, (_, i) => {
      const photo = list[(tick + i) % list.length];
      const slot = SLOTS[(tick + i) % SLOTS.length];
      return { photo, slot, key: `${photo.src}-${i}-${tick}` };
    });
  }, [count, list, tick]);

  if (count <= 0) return null;

  return (
    <div className={cn("pointer-events-none absolute inset-0", className)} aria-hidden>
      {visible.map(({ photo, slot, key }) => (
        <Polaroid key={key} photo={photo} slot={slot} />
      ))}
    </div>
  );
}
