import { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";

type Particle = {
  x: number;
  y: number;
  r: number;
  vx: number;
  vy: number;
  a: number;
};

type Props = {
  density?: number;
  warmth?: number;
  burst?: boolean;
  className?: string;
  reduced?: boolean;
};

export function ParticleField({
  density = 56,
  warmth = 0.25,
  burst = false,
  className,
  reduced = false,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const burstRef = useRef(burst);

  useEffect(() => {
    burstRef.current = burst;
  }, [burst]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d", { alpha: true });
    if (!ctx) return;

    let raf = 0;
    let running = true;
    const particles: Particle[] = [];
    const count = reduced ? Math.min(18, density) : density;

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const { width, height } = canvas.getBoundingClientRect();
      canvas.width = Math.max(1, Math.floor(width * dpr));
      canvas.height = Math.max(1, Math.floor(height * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    const spawn = (explode = false) => {
      particles.length = 0;
      const { width, height } = canvas.getBoundingClientRect();
      for (let i = 0; i < count; i++) {
        const speed = explode ? 1.4 + Math.random() * 2.2 : 0.08 + Math.random() * 0.18;
        const angle = explode ? Math.random() * Math.PI * 2 : -Math.PI / 2 + (Math.random() - 0.5);
        particles.push({
          x: explode ? width * 0.5 : Math.random() * width,
          y: explode ? height * 0.46 : Math.random() * height,
          r: explode ? 1.2 + Math.random() * 2.4 : 0.6 + Math.random() * 1.4,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          a: 0.12 + Math.random() * 0.35,
        });
      }
    };

    resize();
    spawn(false);
    const onResize = () => {
      resize();
    };
    window.addEventListener("resize", onResize);

    let lastBurst = false;
    const loop = () => {
      if (!running) return;
      const { width, height } = canvas.getBoundingClientRect();
      ctx.clearRect(0, 0, width, height);
      const exploding = burstRef.current;
      if (exploding && !lastBurst) spawn(true);
      lastBurst = exploding;

      const gold = warmth > 0.5 ? "232, 201, 160" : "196, 164, 132";
      for (const p of particles) {
        p.x += exploding ? p.vx : p.vx * 0.35;
        p.y += exploding ? p.vy : p.vy - 0.05;
        if (!exploding) {
          if (p.y < -8) p.y = height + 8;
          if (p.x < -8) p.x = width + 8;
          if (p.x > width + 8) p.x = -8;
        }
        ctx.beginPath();
        ctx.fillStyle = `rgba(${gold}, ${p.a * (0.55 + warmth * 0.6)})`;
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      }
      raf = requestAnimationFrame(loop);
    };

    if (reduced) {
      spawn(false);
      const { width, height } = canvas.getBoundingClientRect();
      ctx.clearRect(0, 0, width, height);
      for (const p of particles) {
        ctx.beginPath();
        ctx.fillStyle = `rgba(196, 164, 132, ${p.a * 0.45})`;
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      }
    } else {
      raf = requestAnimationFrame(loop);
    }

    return () => {
      running = false;
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", onResize);
    };
  }, [density, reduced, warmth]);

  return (
    <canvas
      ref={canvasRef}
      className={cn("pointer-events-none absolute inset-0 h-full w-full", className)}
      aria-hidden
    />
  );
}
