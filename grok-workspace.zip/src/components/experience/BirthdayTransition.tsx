import { useLayoutEffect, useRef } from "react";
import gsap from "gsap";
import { photos } from "@/config/birthday";
import { FlowerField } from "@/components/experience/FlowerField";
import { ParticleField } from "@/components/experience/ParticleField";
import { TeddyBear } from "@/components/experience/TeddyBear";

type Props = {
  reduced: boolean;
  onComplete: () => void;
};

export function BirthdayTransition({ reduced, onComplete }: Props) {
  const root = useRef<HTMLDivElement>(null);
  const done = useRef(onComplete);
  done.current = onComplete;

  useLayoutEffect(() => {
    const el = root.current;
    if (!el) return;
    const ctx = gsap.context(() => {
      if (reduced) {
        gsap.set("[data-title]", { opacity: 1, y: 0, filter: "none" });
        gsap.set("[data-burst-photo]", { opacity: 0.7 });
        const t = window.setTimeout(() => done.current(), 1200);
        return () => window.clearTimeout(t);
      }

      const tl = gsap.timeline({
        defaults: { ease: "power2.out" },
        onComplete: () => done.current(),
      });

      tl.fromTo("[data-flash]", { opacity: 0 }, { opacity: 0.22, duration: 0.18 }).to(
        "[data-flash]",
        { opacity: 0, duration: 1.4, ease: "power1.out" },
      );

      tl.fromTo(
        "[data-burst-photo]",
        { opacity: 0, scale: 0.86, filter: "blur(8px)" },
        {
          opacity: 0.88,
          scale: 1,
          filter: "blur(0px)",
          duration: 1.1,
          stagger: 0.08,
        },
        0.2,
      );

      tl.fromTo(
        "[data-title]",
        { opacity: 0, y: 22, filter: "blur(10px)" },
        { opacity: 1, y: 0, filter: "blur(0px)", duration: 1.4 },
        0.7,
      );

      tl.to("[data-burst-photo]", { opacity: 0.25, duration: 1.4 }, 3.2);
      tl.to("[data-title]", { opacity: 1, duration: 0.4 }, 3.6);
      tl.to({}, { duration: 1.4 });
    }, el);
    return () => ctx.revert();
  }, [reduced]);

  const burst = photos.slice(0, 6);

  return (
    <div ref={root} className="absolute inset-0 overflow-hidden bg-void">
      <div data-flash className="pointer-events-none absolute inset-0 bg-candle opacity-0" />
      <ParticleField density={90} warmth={0.85} burst reduced={reduced} />
      <FlowerField motion={0.9} extra reduced={reduced} />
      <TeddyBear celebrate reduced={reduced} />

      {burst.map((photo, i) => {
        const angle = (i / burst.length) * Math.PI * 2 - Math.PI / 2;
        const radius = 38;
        const left = 50 + Math.cos(angle) * radius;
        const top = 48 + Math.sin(angle) * 32;
        return (
          <figure
            key={photo.src}
            data-burst-photo
            className="absolute w-20 overflow-hidden rounded-sm bg-ivory p-1 opacity-0 shadow-2xl sm:w-28"
            style={{
              left: `${left}%`,
              top: `${top}%`,
              transform: `translate(-50%, -50%) rotate(${i % 2 === 0 ? -8 : 7}deg)`,
            }}
          >
            <img
              src={photo.src}
              alt=""
              className="aspect-[4/5] w-full object-cover"
              style={{ objectPosition: photo.objectPosition }}
            />
          </figure>
        );
      })}

      <div className="vignette absolute inset-0" />
      <div className="relative z-10 flex h-full flex-col items-center justify-center px-8">
        <h1
          data-title
          className="font-display max-w-sm text-center text-4xl text-ivory italic opacity-0 sm:text-6xl"
        >
          Happy Birthday, Srijoni.
        </h1>
      </div>
    </div>
  );
}
