import { useLayoutEffect, useRef } from "react";
import gsap from "gsap";
import { openingLines } from "@/config/birthday";
import { FlowerField } from "@/components/experience/FlowerField";
import { ParticleField } from "@/components/experience/ParticleField";
import { TeddyBear } from "@/components/experience/TeddyBear";

type Props = {
  alreadyHere: boolean;
  reduced: boolean;
  onComplete: () => void;
};

export function OpeningScene({ alreadyHere, reduced, onComplete }: Props) {
  const root = useRef<HTMLDivElement>(null);
  const done = useRef(onComplete);
  done.current = onComplete;
  const finished = useRef(false);

  const finish = () => {
    if (finished.current) return;
    finished.current = true;
    done.current();
  };

  useLayoutEffect(() => {
    const el = root.current;
    if (!el) return;
    const lines = el.querySelectorAll("[data-line]");
    const ctx = gsap.context(() => {
      if (reduced) {
        gsap.set(lines, { opacity: 1, y: 0, filter: "blur(0px)" });
        const t = window.setTimeout(() => finish(), 900);
        return () => window.clearTimeout(t);
      }

      const tl = gsap.timeline({
        defaults: { ease: "power2.out" },
        onComplete: () => finish(),
      });

      tl.fromTo(
        "[data-world]",
        { opacity: 0 },
        { opacity: 1, duration: 2.2 },
        0,
      );

      lines.forEach((line, i) => {
        const at = 1.2 + i * 2.45;
        tl.fromTo(
          line,
          { opacity: 0, y: 16, filter: "blur(8px)" },
          { opacity: 1, y: 0, filter: "blur(0px)", duration: 1.15 },
          at,
        );
        if (i < lines.length - 1) {
          tl.to(line, { opacity: 0, y: -10, filter: "blur(6px)", duration: 0.7 }, at + 2.05);
        }
      });

      tl.to(
        lines,
        { opacity: 0, y: -12, filter: "blur(8px)", duration: 0.8, stagger: 0.08 },
        "+=1.15",
      );
    }, el);

    return () => ctx.revert();
  }, [alreadyHere, reduced]);

  const copy = alreadyHere ? openingLines.alreadyHere : openingLines.waiting;

  return (
    <div
      ref={root}
      className="absolute inset-0 overflow-hidden bg-void"
      onClick={() => finish()}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") finish();
      }}
      role="button"
      tabIndex={0}
      aria-label="Enter the birthday world"
    >
      <div data-world className="absolute inset-0 opacity-0">
        <ParticleField density={40} warmth={0.18} reduced={reduced} />
        <FlowerField motion={0.28} reduced={reduced} />
        <TeddyBear motion={0.28} reduced={reduced} />
      </div>
      <div className="vignette absolute inset-0" />
      <div className="relative z-10 flex h-full items-center justify-center px-8">
        <div className="flex min-h-24 flex-col items-center">
          {copy.map((text) => (
            <p
              key={text}
              data-line
              className="font-display absolute text-center text-3xl text-ivory italic opacity-0 sm:text-4xl"
            >
              {text}
            </p>
          ))}
        </div>
      </div>
    </div>
  );
}
