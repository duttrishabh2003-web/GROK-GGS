import { finale, photos } from "@/config/birthday";

export function FinalScene() {
  return (
    <section className="relative flex min-h-[100dvh] flex-col items-center justify-center overflow-hidden px-6 py-28">
      <img
        src={photos[1].src}
        alt=""
        className="pointer-events-none absolute top-[12%] left-[8%] w-24 rotate-[-12deg] opacity-25 sm:w-32"
        aria-hidden
      />
      <img
        src={photos[0].src}
        alt=""
        className="pointer-events-none absolute right-[6%] bottom-[22%] w-20 rotate-[9deg] opacity-20 sm:w-28"
        aria-hidden
      />
      <img
        src="/garden/teddy-mocha.webp"
        alt=""
        className="pointer-events-none absolute bottom-[8%] left-[6%] w-24 opacity-80 sm:w-32"
        aria-hidden
      />
      <img
        src="/garden/rose-stem.webp"
        alt=""
        className="pointer-events-none mx-auto mb-12 w-36 mix-blend-lighten sm:w-44"
      />
      <h2 className="font-display max-w-sm text-center text-3xl text-ivory italic sm:text-4xl">
        {finale.title}
      </h2>
      <p className="mt-5 text-[0.7rem] tracking-[0.38em] text-champagne uppercase">
        {finale.subtitle}
      </p>
      <p className="font-display mt-10 max-w-xs text-center text-lg leading-relaxed text-ivory-dim italic">
        {finale.line}
      </p>
    </section>
  );
}
