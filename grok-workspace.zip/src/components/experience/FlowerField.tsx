import { flowers, type GardenSprite } from "@/config/birthday";
import { cn } from "@/lib/utils";

type Props = {
  motion?: number;
  extra?: boolean;
  className?: string;
  reduced?: boolean;
};

function Flower({
  flower,
  motion,
  reduced,
}: {
  flower: GardenSprite;
  motion: number;
  reduced: boolean;
}) {
  return (
    <img
      src={flower.src}
      alt=""
      className={cn(
        "pointer-events-none absolute select-none",
        !flower.mobile && "hidden md:block",
        !reduced && "sway",
      )}
      style={{
        left: flower.x,
        top: flower.y,
        width: flower.w,
        opacity: (flower.opacity ?? 0.8) * (0.55 + motion * 0.55),
        mixBlendMode: flower.blend === "lighten" ? "lighten" : "normal",
        ["--r" as string]: `${flower.rotate}deg`,
        ["--dur" as string]: `${flower.duration / Math.max(0.4, motion + 0.3)}s`,
        ["--delay" as string]: `${flower.delay}s`,
      }}
      draggable={false}
    />
  );
}

export function FlowerField({ motion = 0.35, extra = false, className, reduced = false }: Props) {
  const shown = extra ? flowers : flowers.slice(0, 4);
  return (
    <div className={cn("pointer-events-none absolute inset-0 overflow-hidden", className)} aria-hidden>
      {shown.map((flower, i) => (
        <Flower key={`${flower.src}-${i}`} flower={flower} motion={motion} reduced={reduced} />
      ))}
    </div>
  );
}
