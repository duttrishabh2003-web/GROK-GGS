import { useLayoutEffect, useRef } from "react";
import gsap from "gsap";
import { pad2 } from "@/lib/ist-time";

type Props = {
  seconds: number;
  reduced: boolean;
};

export function FinalTen({ seconds, reduced }: Props) {
  const ref = useRef<HTMLSpanElement>(null);
  const prev = useRef(seconds);

  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (prev.current === seconds) return;
    prev.current = seconds;
    if (reduced) return;
    gsap.fromTo(
      el,
      { scale: 1.18, opacity: 0.2, filter: "blur(12px)" },
      { scale: 1, opacity: 1, filter: "blur(0px)", duration: 0.55, ease: "power3.out" },
    );
  }, [seconds, reduced]);

  return (
    <div className="relative z-20 flex h-full flex-col items-center justify-center">
      <p className="mb-6 text-[0.7rem] tracking-[0.5em] text-champagne uppercase">Almost</p>
      <span
        ref={ref}
        className="font-light text-ivory tabular-nums"
        style={{ fontSize: "clamp(5.5rem, 28vw, 11rem)", letterSpacing: "-0.06em", lineHeight: 0.9 }}
      >
        {pad2(Math.max(0, seconds))}
      </span>
    </div>
  );
}
