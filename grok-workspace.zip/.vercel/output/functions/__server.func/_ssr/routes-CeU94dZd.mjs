import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Lenis } from "../_libs/lenis.mjs";
import { t as gsapWithCSS } from "../_libs/gsap.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CeU94dZd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var birthday = {
	name: "Srijoni",
	target: {
		year: 2026,
		month: 9,
		day: 30,
		hour: 0,
		minute: 0,
		second: 0
	},
	monthsTogether: 7
};
/**
* Add a photograph by appending an entry. The waiting world and the
* memory chapters pick up whatever is in this list automatically.
*/
var photos = [
	{
		src: "/photos/saree-stairs.webp",
		alt: "Srijoni sitting on marble stairs in a gold saree",
		objectPosition: "center 18%"
	},
	{
		src: "/photos/portrait-sweater.webp",
		alt: "Srijoni looking into the camera",
		objectPosition: "center 15%"
	},
	{
		src: "/photos/flower-hair.webp",
		alt: "Srijoni with a pink flower in her hair",
		objectPosition: "center 20%"
	},
	{
		src: "/photos/kurta-selfie.webp",
		alt: "Srijoni taking a mirror photograph",
		objectPosition: "center 20%"
	},
	{
		src: "/photos/lipstick-mirror.webp",
		alt: "Srijoni in a red top at a bathroom mirror",
		objectPosition: "center 40%"
	},
	{
		src: "/photos/covering-smile.webp",
		alt: "Srijoni covering part of her face, smiling",
		objectPosition: "center 35%"
	},
	{
		src: "/photos/closeup-dots.webp",
		alt: "Close portrait of Srijoni",
		objectPosition: "center 30%"
	},
	{
		src: "/photos/mirror-white.webp",
		alt: "Srijoni in a white embroidered dress",
		objectPosition: "center 25%"
	},
	{
		src: "/photos/pink-squint.webp",
		alt: "Srijoni squinting, laughing",
		objectPosition: "center 20%"
	},
	{
		src: "/photos/anime-glance.webp",
		alt: "An illustration of a girl looking down",
		objectPosition: "center 30%"
	},
	{
		src: "/photos/bunny-plush.webp",
		alt: "A worn pink plush bunny",
		objectPosition: "center 40%"
	}
];
var flowers = [
	{
		src: "/garden/rose-ivory.webp",
		x: "-8%",
		y: "58%",
		w: "13.5rem",
		rotate: -18,
		delay: 0,
		duration: 11,
		mobile: true,
		blend: "lighten",
		opacity: .88
	},
	{
		src: "/garden/peony-blush.webp",
		x: "72%",
		y: "-4%",
		w: "11rem",
		rotate: 14,
		delay: 1.2,
		duration: 13,
		mobile: true,
		blend: "lighten",
		opacity: .8
	},
	{
		src: "/garden/rose-burgundy.webp",
		x: "78%",
		y: "62%",
		w: "10.5rem",
		rotate: 8,
		delay: .6,
		duration: 12,
		mobile: true,
		blend: "lighten",
		opacity: .78
	},
	{
		src: "/garden/jasmine.webp",
		x: "-2%",
		y: "6%",
		w: "9.5rem",
		rotate: -8,
		delay: 1.8,
		duration: 14,
		mobile: false,
		blend: "lighten",
		opacity: .7
	},
	{
		src: "/garden/rose-stem.webp",
		x: "38%",
		y: "78%",
		w: "8rem",
		rotate: 22,
		delay: 2.4,
		duration: 16,
		mobile: false,
		blend: "lighten",
		opacity: .55
	},
	{
		src: "/garden/peony-blush.webp",
		x: "8%",
		y: "78%",
		w: "7.5rem",
		rotate: -28,
		delay: 3,
		duration: 15,
		mobile: false,
		blend: "lighten",
		opacity: .5
	}
];
var teddies = [{
	src: "/garden/teddy-mocha.webp",
	x: "-4%",
	y: "70%",
	w: "8.5rem",
	rotate: -6,
	delay: .4,
	duration: 6.5,
	mobile: true,
	blend: "normal",
	opacity: .92
}, {
	src: "/garden/teddy-rose.webp",
	x: "76%",
	y: "72%",
	w: "7.8rem",
	rotate: 8,
	delay: 1.1,
	duration: 7.4,
	mobile: true,
	blend: "normal",
	opacity: .9
}];
var cake = {
	theme: "midnight-garden",
	src: "/garden/cake-whole.webp",
	cutSrc: "/garden/cake-cut.webp",
	canCut: true,
	wish: "Make a wish."
};
var openingLines = {
	waiting: [
		"Hey, Srijoni.",
		"I made you something.",
		"Stay until the clock reaches zero."
	],
	alreadyHere: ["Hey, Srijoni.", "It's already your day."]
};
var waitingLine = "I couldn't be there when the clock turns to your birthday, so I built a little world that waits with you until it does.";
var personalMessage = [
	"I wanted to be in the room when the date changed.",
	"I couldn't. Distance gets a say in the furniture. It doesn't get a say in the day.",
	"So I stayed up with a clock instead, and I built you a place to wait inside."
];
var letter = {
	greeting: "Srijoni,",
	body: [
		"I couldn't be there when the clock turns.",
		"There's a version of tonight where I'm in the same room — watching the numbers become a date, saying the thing out loud instead of building a place to hold it. That version isn't this one. Distance decided that. I didn't.",
		"So I made this. A small world that waits the way I would have waited. Dark at first. Then flowers. Then your face, again and again, because that's the part I keep.",
		"Seven months of us, and I still look at the same photographs like they might tell me something new. They don't have to. They're already enough.",
		"I keep thinking of midnight as a kind of meeting place. You on one side of it. Me on the other. The same second, just not the same floor. Clocks are honest like that. They don't care who is missing from the room. They just keep going until the day belongs to you.",
		"I wish I could hand you something with weight. A flower that isn't made of light. A cake that actually takes up space on a table. The ordinary, clumsy, physical kind of birthday.",
		"This is the closest I could get from here.",
		"You matter to me in the quiet way — the way that doesn't need an audience. These seven months aren't a preview of something. They're already the thing. I don't know when the road between us gets shorter. I just know I want to be on it when it does.",
		"Until then: I hope this night feels like it was kept for you."
	],
	signoff: "Happy Birthday, Srijoni.",
	closing: "still here. still yours. still counting."
};
var finale = {
	title: "Happy Birthday, Srijoni.",
	subtitle: "Seven months of us.",
	line: "Some distances are just time that hasn't finished walking yet."
};
/**
* Birthday midnight in Asia/Kolkata (IST, UTC+5:30).
* India does not observe daylight saving — the offset is fixed.
* Remaining time is always derived from timestamps, never decremented.
*/
var IST_OFFSET = "+05:30";
function pad2(n) {
	return n.toString().padStart(2, "0");
}
function targetIso(t) {
	const hour = t.hour ?? 0;
	const minute = t.minute ?? 0;
	const second = t.second ?? 0;
	return `${t.year}-${pad2(t.month)}-${pad2(t.day)}T${pad2(hour)}:${pad2(minute)}:${pad2(second)}${IST_OFFSET}`;
}
function getTargetMs(t) {
	return Date.parse(targetIso(t));
}
function splitRemaining(ms) {
	const remainingMs = Math.max(0, ms);
	const totalSeconds = Math.floor(remainingMs / 1e3);
	return {
		days: Math.floor(totalSeconds / 86400),
		hours: Math.floor(totalSeconds % 86400 / 3600),
		minutes: Math.floor(totalSeconds % 3600 / 60),
		seconds: totalSeconds % 60,
		totalSeconds,
		remainingMs,
		isZero: ms <= 0
	};
}
function atmosphereFromRemaining(ms) {
	if (ms <= 0) return {
		level: "zero",
		warmth: 1,
		motion: .5,
		photoCount: 6
	};
	const minutes = ms / 6e4;
	const hours = ms / 36e5;
	if (ms / 1e3 <= 10) return {
		level: "final10",
		warmth: .9,
		motion: .12,
		photoCount: 0
	};
	if (minutes <= 1) return {
		level: "minute",
		warmth: .82,
		motion: .92,
		photoCount: 3
	};
	if (minutes <= 10) return {
		level: "tenmin",
		warmth: .68,
		motion: .78,
		photoCount: 2
	};
	if (minutes <= 30) return {
		level: "halfhour",
		warmth: .52,
		motion: .62,
		photoCount: 2
	};
	if (hours <= 1) return {
		level: "hour",
		warmth: .4,
		motion: .5,
		photoCount: 1
	};
	return {
		level: "calm",
		warmth: .22,
		motion: .34,
		photoCount: 1
	};
}
function useCountdown(fakeRemainingMs = null) {
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	const fake = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (fakeRemainingMs == null) {
			fake.current = null;
			return;
		}
		fake.current = {
			origin: Date.now(),
			remaining: fakeRemainingMs
		};
		setNow(Date.now());
	}, [fakeRemainingMs]);
	(0, import_react.useEffect)(() => {
		let timeout = 0;
		const tick = () => {
			setNow(Date.now());
			timeout = window.setTimeout(tick, 250);
		};
		tick();
		const refresh = () => setNow(Date.now());
		document.addEventListener("visibilitychange", refresh);
		window.addEventListener("focus", refresh);
		window.addEventListener("pageshow", refresh);
		return () => {
			window.clearTimeout(timeout);
			document.removeEventListener("visibilitychange", refresh);
			window.removeEventListener("focus", refresh);
			window.removeEventListener("pageshow", refresh);
		};
	}, []);
	const targetMs = getTargetMs(birthday.target);
	const remainingMs = fake.current ? fake.current.remaining - (now - fake.current.origin) : targetMs - now;
	return {
		...splitRemaining(remainingMs),
		atmosphere: atmosphereFromRemaining(remainingMs),
		targetMs,
		now
	};
}
function useLenis(enabled) {
	(0, import_react.useEffect)(() => {
		if (!enabled) return;
		const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const lenis = new Lenis({
			lerp: reduced ? 1 : .085,
			smoothWheel: !reduced,
			syncTouch: false
		});
		let raf = 0;
		const loop = (time) => {
			lenis.raf(time);
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		return () => {
			cancelAnimationFrame(raf);
			lenis.destroy();
		};
	}, [enabled]);
}
function usePrefersReducedMotion() {
	const [reduced, setReduced] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
		const onChange = () => setReduced(mq.matches);
		onChange();
		mq.addEventListener("change", onChange);
		return () => mq.removeEventListener("change", onChange);
	}, []);
	return reduced;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Flower({ flower, motion, reduced }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: flower.src,
		alt: "",
		className: cn("pointer-events-none absolute select-none", !flower.mobile && "hidden md:block", !reduced && "sway"),
		style: {
			left: flower.x,
			top: flower.y,
			width: flower.w,
			opacity: (flower.opacity ?? .8) * (.55 + motion * .55),
			mixBlendMode: flower.blend === "lighten" ? "lighten" : "normal",
			["--r"]: `${flower.rotate}deg`,
			["--dur"]: `${flower.duration / Math.max(.4, motion + .3)}s`,
			["--delay"]: `${flower.delay}s`
		},
		draggable: false
	});
}
function FlowerField({ motion = .35, extra = false, className, reduced = false }) {
	const shown = extra ? flowers : flowers.slice(0, 4);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("pointer-events-none absolute inset-0 overflow-hidden", className),
		"aria-hidden": true,
		children: shown.map((flower, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flower, {
			flower,
			motion,
			reduced
		}, `${flower.src}-${i}`))
	});
}
function ParticleField({ density = 56, warmth = .25, burst = false, className, reduced = false }) {
	const canvasRef = (0, import_react.useRef)(null);
	const burstRef = (0, import_react.useRef)(burst);
	(0, import_react.useEffect)(() => {
		burstRef.current = burst;
	}, [burst]);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d", { alpha: true });
		if (!ctx) return;
		let raf = 0;
		let running = true;
		const particles = [];
		const count = reduced ? Math.min(18, density) : density;
		const resize = () => {
			const dpr = Math.min(window.devicePixelRatio || 1, 2);
			const { width, height } = canvas.getBoundingClientRect();
			canvas.width = Math.max(1, Math.floor(width * dpr));
			canvas.height = Math.max(1, Math.floor(height * dpr));
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		};
		const spawn = (explode = false) => {
			particles.length = 0;
			const { width, height } = canvas.getBoundingClientRect();
			for (let i = 0; i < count; i++) {
				const speed = explode ? 1.4 + Math.random() * 2.2 : .08 + Math.random() * .18;
				const angle = explode ? Math.random() * Math.PI * 2 : -Math.PI / 2 + (Math.random() - .5);
				particles.push({
					x: explode ? width * .5 : Math.random() * width,
					y: explode ? height * .46 : Math.random() * height,
					r: explode ? 1.2 + Math.random() * 2.4 : .6 + Math.random() * 1.4,
					vx: Math.cos(angle) * speed,
					vy: Math.sin(angle) * speed,
					a: .12 + Math.random() * .35
				});
			}
		};
		resize();
		spawn(false);
		const onResize = () => {
			resize();
		};
		window.addEventListener("resize", onResize);
		let lastBurst = false;
		const loop = () => {
			if (!running) return;
			const { width, height } = canvas.getBoundingClientRect();
			ctx.clearRect(0, 0, width, height);
			const exploding = burstRef.current;
			if (exploding && !lastBurst) spawn(true);
			lastBurst = exploding;
			const gold = warmth > .5 ? "232, 201, 160" : "196, 164, 132";
			for (const p of particles) {
				p.x += exploding ? p.vx : p.vx * .35;
				p.y += exploding ? p.vy : p.vy - .05;
				if (!exploding) {
					if (p.y < -8) p.y = height + 8;
					if (p.x < -8) p.x = width + 8;
					if (p.x > width + 8) p.x = -8;
				}
				ctx.beginPath();
				ctx.fillStyle = `rgba(${gold}, ${p.a * (.55 + warmth * .6)})`;
				ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
				ctx.fill();
			}
			raf = requestAnimationFrame(loop);
		};
		if (reduced) {
			spawn(false);
			const { width, height } = canvas.getBoundingClientRect();
			ctx.clearRect(0, 0, width, height);
			for (const p of particles) {
				ctx.beginPath();
				ctx.fillStyle = `rgba(196, 164, 132, ${p.a * .45})`;
				ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
				ctx.fill();
			}
		} else raf = requestAnimationFrame(loop);
		return () => {
			running = false;
			cancelAnimationFrame(raf);
			window.removeEventListener("resize", onResize);
		};
	}, [
		density,
		reduced,
		warmth
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref: canvasRef,
		className: cn("pointer-events-none absolute inset-0 h-full w-full", className),
		"aria-hidden": true
	});
}
function Bear({ bear, reduced, celebrate }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: bear.src,
		alt: "",
		className: cn("pointer-events-none absolute select-none drop-shadow-[0_18px_30px_rgba(0,0,0,0.55)]", !bear.mobile && "hidden md:block", !reduced && "breathe"),
		style: {
			left: celebrate ? bear.x.startsWith("-") ? "8%" : "70%" : bear.x,
			top: celebrate ? "58%" : bear.y,
			width: bear.w,
			opacity: bear.opacity ?? .9,
			mixBlendMode: "normal",
			["--r"]: `${bear.rotate}deg`,
			["--dur"]: `${bear.duration}s`,
			["--delay"]: `${bear.delay}s`,
			transition: "left 1.6s cubic-bezier(0.22, 1, 0.36, 1), top 1.6s cubic-bezier(0.22, 1, 0.36, 1)"
		},
		draggable: false
	});
}
function TeddyBear({ motion = .35, className, reduced = false, celebrate = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("pointer-events-none absolute inset-0 overflow-hidden", className),
		"aria-hidden": true,
		children: teddies.map((bear, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bear, {
			bear,
			reduced,
			celebrate
		}, `${bear.src}-${i}`))
	});
}
function BirthdayTransition({ reduced, onComplete }) {
	const root = (0, import_react.useRef)(null);
	const done = (0, import_react.useRef)(onComplete);
	done.current = onComplete;
	(0, import_react.useLayoutEffect)(() => {
		const el = root.current;
		if (!el) return;
		const ctx = gsapWithCSS.context(() => {
			if (reduced) {
				gsapWithCSS.set("[data-title]", {
					opacity: 1,
					y: 0,
					filter: "none"
				});
				gsapWithCSS.set("[data-burst-photo]", { opacity: .7 });
				const t = window.setTimeout(() => done.current(), 1200);
				return () => window.clearTimeout(t);
			}
			const tl = gsapWithCSS.timeline({
				defaults: { ease: "power2.out" },
				onComplete: () => done.current()
			});
			tl.fromTo("[data-flash]", { opacity: 0 }, {
				opacity: .22,
				duration: .18
			}).to("[data-flash]", {
				opacity: 0,
				duration: 1.4,
				ease: "power1.out"
			});
			tl.fromTo("[data-burst-photo]", {
				opacity: 0,
				scale: .86,
				filter: "blur(8px)"
			}, {
				opacity: .88,
				scale: 1,
				filter: "blur(0px)",
				duration: 1.1,
				stagger: .08
			}, .2);
			tl.fromTo("[data-title]", {
				opacity: 0,
				y: 22,
				filter: "blur(10px)"
			}, {
				opacity: 1,
				y: 0,
				filter: "blur(0px)",
				duration: 1.4
			}, .7);
			tl.to("[data-burst-photo]", {
				opacity: .25,
				duration: 1.4
			}, 3.2);
			tl.to("[data-title]", {
				opacity: 1,
				duration: .4
			}, 3.6);
			tl.to({}, { duration: 1.4 });
		}, el);
		return () => ctx.revert();
	}, [reduced]);
	const burst = photos.slice(0, 6);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: root,
		className: "absolute inset-0 overflow-hidden bg-void",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"data-flash": true,
				className: "pointer-events-none absolute inset-0 bg-candle opacity-0"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ParticleField, {
				density: 90,
				warmth: .85,
				burst: true,
				reduced
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlowerField, {
				motion: .9,
				extra: true,
				reduced
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeddyBear, {
				celebrate: true,
				reduced
			}),
			burst.map((photo, i) => {
				const angle = i / burst.length * Math.PI * 2 - Math.PI / 2;
				const left = 50 + Math.cos(angle) * 38;
				const top = 48 + Math.sin(angle) * 32;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
					"data-burst-photo": true,
					className: "absolute w-20 overflow-hidden rounded-sm bg-ivory p-1 opacity-0 shadow-2xl sm:w-28",
					style: {
						left: `${left}%`,
						top: `${top}%`,
						transform: `translate(-50%, -50%) rotate(${i % 2 === 0 ? -8 : 7}deg)`
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: photo.src,
						alt: "",
						className: "aspect-[4/5] w-full object-cover",
						style: { objectPosition: photo.objectPosition }
					})
				}, photo.src);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "vignette absolute inset-0" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative z-10 flex h-full flex-col items-center justify-center px-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					"data-title": true,
					className: "font-display max-w-sm text-center text-4xl text-ivory italic opacity-0 sm:text-6xl",
					children: "Happy Birthday, Srijoni."
				})
			})
		]
	});
}
function CakeScene() {
	const [cut, setCut] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative flex min-h-[100dvh] flex-col items-center justify-center px-6 py-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-[0.65rem] tracking-[0.42em] text-champagne uppercase",
				children: cake.theme.replace("-", " ")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display mb-10 text-center text-2xl text-ivory italic",
				children: cake.wish
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				disabled: !cake.canCut,
				onClick: () => setCut(true),
				className: "group relative max-w-sm transition-transform duration-150 ease-out active:scale-[0.96]",
				"aria-label": cut ? "Birthday cake" : "Tap the cake",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: cake.src,
						alt: "Ivory birthday cake with flowers and gold candles",
						className: cn("w-[min(86vw,22rem)] transition-opacity duration-700", cut ? "opacity-0" : "opacity-100"),
						draggable: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: cake.cutSrc,
						alt: "",
						className: cn("absolute inset-0 w-[min(86vw,22rem)] transition-opacity duration-700", cut ? "opacity-100" : "opacity-0"),
						draggable: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "pointer-events-none absolute inset-x-12 top-8 h-16 rounded-full bg-candle/20 blur-2xl",
						"aria-hidden": true
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 min-h-6 text-center text-sm tracking-[0.16em] text-muted",
				children: cake.canCut ? cut ? "that's yours." : "tap the cake." : null
			})
		]
	});
}
function TickNumber({ value, className }) {
	const ref = (0, import_react.useRef)(null);
	const prev = (0, import_react.useRef)(value);
	(0, import_react.useLayoutEffect)(() => {
		const el = ref.current;
		if (!el) return;
		if (prev.current === value) return;
		prev.current = value;
		gsapWithCSS.fromTo(el, {
			y: 10,
			opacity: .35,
			filter: "blur(5px)"
		}, {
			y: 0,
			opacity: 1,
			filter: "blur(0px)",
			duration: .38,
			ease: "power2.out"
		});
	}, [value]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		ref,
		className: cn("inline-block tabular-nums", className),
		children: value
	});
}
function Unit({ value, label, large }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col items-center gap-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TickNumber, {
			value: pad2(value),
			className: cn("font-light tracking-tight text-ivory", large ? "text-5xl sm:text-6xl md:text-7xl" : "text-4xl sm:text-5xl md:text-6xl")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[0.62rem] font-normal tracking-[0.38em] text-champagne/80 uppercase sm:text-xs",
			children: label
		})]
	});
}
function CountdownClock({ days, hours, minutes, seconds, line, compact = false, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative z-10 flex flex-col items-center px-4", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-8 text-[0.65rem] tracking-[0.42em] text-muted uppercase",
				children: "IST · midnight"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("grid w-full max-w-lg grid-cols-4 items-end", compact ? "gap-3 sm:gap-6" : "gap-4 sm:gap-8"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Unit, {
						value: days,
						label: "Days"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Unit, {
						value: hours,
						label: "Hours",
						large: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Unit, {
						value: minutes,
						label: "Minutes",
						large: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Unit, {
						value: seconds,
						label: "Seconds"
					})
				]
			}),
			line ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display mt-10 max-w-sm text-center text-base leading-relaxed text-ivory-dim italic sm:text-lg",
				children: line
			}) : null
		]
	});
}
function FinalScene() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative flex min-h-[100dvh] flex-col items-center justify-center overflow-hidden px-6 py-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: photos[1].src,
				alt: "",
				className: "pointer-events-none absolute top-[12%] left-[8%] w-24 rotate-[-12deg] opacity-25 sm:w-32",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: photos[0].src,
				alt: "",
				className: "pointer-events-none absolute right-[6%] bottom-[22%] w-20 rotate-[9deg] opacity-20 sm:w-28",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/garden/teddy-mocha.webp",
				alt: "",
				className: "pointer-events-none absolute bottom-[8%] left-[6%] w-24 opacity-80 sm:w-32",
				"aria-hidden": true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/garden/rose-stem.webp",
				alt: "",
				className: "pointer-events-none mx-auto mb-12 w-36 mix-blend-lighten sm:w-44"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display max-w-sm text-center text-3xl text-ivory italic sm:text-4xl",
				children: finale.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 text-[0.7rem] tracking-[0.38em] text-champagne uppercase",
				children: finale.subtitle
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display mt-10 max-w-xs text-center text-lg leading-relaxed text-ivory-dim italic",
				children: finale.line
			})
		]
	});
}
function FinalTen({ seconds, reduced }) {
	const ref = (0, import_react.useRef)(null);
	const prev = (0, import_react.useRef)(seconds);
	(0, import_react.useLayoutEffect)(() => {
		const el = ref.current;
		if (!el) return;
		if (prev.current === seconds) return;
		prev.current = seconds;
		if (reduced) return;
		gsapWithCSS.fromTo(el, {
			scale: 1.18,
			opacity: .2,
			filter: "blur(12px)"
		}, {
			scale: 1,
			opacity: 1,
			filter: "blur(0px)",
			duration: .55,
			ease: "power3.out"
		});
	}, [seconds, reduced]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative z-20 flex h-full flex-col items-center justify-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-6 text-[0.7rem] tracking-[0.5em] text-champagne uppercase",
			children: "Almost"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			ref,
			className: "font-light text-ivory tabular-nums",
			style: {
				fontSize: "clamp(5.5rem, 28vw, 11rem)",
				letterSpacing: "-0.06em",
				lineHeight: .9
			},
			children: pad2(Math.max(0, seconds))
		})]
	});
}
function Frame({ src, alt, objectPosition, className, rotate = 0, style }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
		className: cn("overflow-hidden bg-ivory p-1.5 shadow-[0_20px_50px_rgba(0,0,0,0.45)]", className),
		style: {
			transform: `rotate(${rotate}deg)`,
			...style
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src,
			alt,
			className: "h-full w-full object-cover",
			style: { objectPosition: objectPosition ?? "center" },
			loading: "lazy",
			draggable: false
		})
	});
}
function MemoryGallery() {
	const saree = photos[0];
	const portrait = photos[1];
	const flowerHair = photos[2];
	const kurta = photos[3];
	const lipstick = photos[4];
	const covering = photos[5];
	const closeup = photos[6];
	const whiteDress = photos[7];
	const squint = photos[8];
	const bunny = photos[10];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative flex min-h-[100dvh] flex-col justify-center px-5 py-16 md:px-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-8 text-center text-[0.65rem] tracking-[0.42em] text-champagne uppercase",
					children: "this light"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex w-full max-w-3xl flex-col items-center gap-8 md:flex-row md:items-end md:justify-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
						src: saree.src,
						alt: saree.alt,
						objectPosition: saree.objectPosition,
						className: "h-[62vw] w-[78%] max-h-[28rem] max-w-sm md:h-[28rem] md:w-[22rem]",
						rotate: -2.5
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
						src: portrait.src,
						alt: portrait.alt,
						objectPosition: portrait.objectPosition,
						className: "h-44 w-36 md:h-56 md:w-44",
						rotate: 7
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative flex min-h-[100dvh] flex-col justify-center px-5 py-16 md:px-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-8 text-center text-[0.65rem] tracking-[0.42em] text-champagne uppercase",
					children: "the rooms you occupy"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid w-full max-w-3xl grid-cols-2 gap-4 md:gap-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
							src: flowerHair.src,
							alt: flowerHair.alt,
							objectPosition: flowerHair.objectPosition,
							className: "aspect-[4/5] w-full",
							rotate: -4
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
							src: kurta.src,
							alt: kurta.alt,
							objectPosition: kurta.objectPosition,
							className: "mt-10 aspect-[4/5] w-full",
							rotate: 5
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
							src: lipstick.src,
							alt: lipstick.alt,
							objectPosition: lipstick.objectPosition,
							className: "col-span-2 mx-auto mt-2 aspect-[4/5] w-44 md:w-56",
							rotate: -3
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative flex min-h-[100dvh] flex-col justify-center px-5 py-16 md:px-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-8 text-center text-[0.65rem] tracking-[0.42em] text-champagne uppercase",
					children: "closer"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex w-full max-w-3xl flex-col items-center gap-8 md:flex-row md:items-center md:justify-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
						src: covering.src,
						alt: covering.alt,
						objectPosition: covering.objectPosition,
						className: "h-[58vw] w-[76%] max-h-[26rem] max-w-sm md:h-[26rem] md:w-[20rem]",
						rotate: 2
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
						src: closeup.src,
						alt: closeup.alt,
						objectPosition: closeup.objectPosition,
						className: "h-48 w-56 md:h-52 md:w-64",
						rotate: -6
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative flex min-h-[100dvh] flex-col justify-center px-5 py-16 md:px-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-8 text-center text-[0.65rem] tracking-[0.42em] text-champagne uppercase",
					children: "and this"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mx-auto h-[30rem] w-full max-w-md",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
							src: whiteDress.src,
							alt: whiteDress.alt,
							objectPosition: whiteDress.objectPosition,
							className: "absolute top-4 left-2 aspect-[3/5] w-40 md:w-48",
							rotate: -8
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
							src: squint.src,
							alt: squint.alt,
							objectPosition: squint.objectPosition,
							className: "absolute top-24 right-2 aspect-[4/5] w-40 md:w-48",
							rotate: 6
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
							src: bunny.src,
							alt: bunny.alt,
							objectPosition: bunny.objectPosition,
							className: "absolute bottom-2 left-1/4 aspect-[3/5] w-32 md:w-40",
							rotate: -2
						})
					]
				})]
			})
		]
	});
}
function OpeningScene({ alreadyHere, reduced, onComplete }) {
	const root = (0, import_react.useRef)(null);
	const done = (0, import_react.useRef)(onComplete);
	done.current = onComplete;
	(0, import_react.useLayoutEffect)(() => {
		const el = root.current;
		if (!el) return;
		const lines = el.querySelectorAll("[data-line]");
		const ctx = gsapWithCSS.context(() => {
			if (reduced) {
				gsapWithCSS.set(lines, {
					opacity: 1,
					y: 0,
					filter: "blur(0px)"
				});
				const t = window.setTimeout(() => done.current(), 900);
				return () => window.clearTimeout(t);
			}
			const tl = gsapWithCSS.timeline({
				defaults: { ease: "power2.out" },
				onComplete: () => done.current()
			});
			tl.fromTo("[data-world]", { opacity: 0 }, {
				opacity: 1,
				duration: 2.2
			}, 0);
			lines.forEach((line, i) => {
				const at = 1.2 + i * 2.45;
				tl.fromTo(line, {
					opacity: 0,
					y: 16,
					filter: "blur(8px)"
				}, {
					opacity: 1,
					y: 0,
					filter: "blur(0px)",
					duration: 1.15
				}, at);
				if (i < lines.length - 1) tl.to(line, {
					opacity: 0,
					y: -10,
					filter: "blur(6px)",
					duration: .7
				}, at + 2.05);
			});
			tl.to(lines, {
				opacity: 0,
				y: -12,
				filter: "blur(8px)",
				duration: .8,
				stagger: .08
			}, "+=1.15");
		}, el);
		return () => ctx.revert();
	}, [alreadyHere, reduced]);
	const copy = alreadyHere ? openingLines.alreadyHere : openingLines.waiting;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: root,
		className: "absolute inset-0 overflow-hidden bg-void",
		onClick: () => done.current(),
		onKeyDown: (e) => {
			if (e.key === "Enter" || e.key === " ") done.current();
		},
		role: "button",
		tabIndex: 0,
		"aria-label": "Enter the birthday world",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				"data-world": true,
				className: "absolute inset-0 opacity-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ParticleField, {
						density: 40,
						warmth: .18,
						reduced
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlowerField, {
						motion: .28,
						reduced
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeddyBear, {
						motion: .28,
						reduced
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "vignette absolute inset-0" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative z-10 flex h-full items-center justify-center px-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex min-h-24 flex-col items-center",
					children: copy.map((text) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						"data-line": true,
						className: "font-display absolute text-center text-3xl text-ivory italic opacity-0 sm:text-4xl",
						children: text
					}, text))
				})
			})
		]
	});
}
var SLOTS = [
	{
		top: "7%",
		left: "4%",
		rotate: -9,
		width: "7.4rem"
	},
	{
		top: "10%",
		right: "3%",
		rotate: 8,
		width: "6.8rem"
	},
	{
		bottom: "16%",
		left: "3%",
		rotate: -6,
		width: "7.6rem"
	},
	{
		bottom: "18%",
		right: "4%",
		rotate: 7,
		width: "7.1rem"
	}
];
function Polaroid({ photo, slot }) {
	const pos = {
		width: slot.width,
		transform: `rotate(${slot.rotate}deg)`,
		..."left" in slot ? { left: slot.left } : { right: slot.right },
		..."top" in slot ? { top: slot.top } : { bottom: slot.bottom }
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "absolute bg-ivory p-1.5 pb-6 shadow-[0_18px_40px_rgba(0,0,0,0.45)] bloom-in",
		style: pos,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "aspect-[4/5] overflow-hidden bg-charcoal",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: photo.src,
				alt: photo.alt,
				className: "h-full w-full object-cover",
				style: { objectPosition: photo.objectPosition ?? "center" },
				draggable: false
			})
		}), photo.caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
			className: "font-display mt-1.5 px-0.5 text-center text-[0.65rem] italic text-charcoal/80",
			children: photo.caption
		}) : null]
	});
}
function PhotoMemory({ count = 1, className, reduced = false, freeze = false }) {
	const [tick, setTick] = (0, import_react.useState)(0);
	const list = photos.filter((p) => !p.src.includes("bunny") && !p.src.includes("anime"));
	(0, import_react.useEffect)(() => {
		if (freeze || reduced) return;
		const id = window.setInterval(() => setTick((n) => n + 1), 7800);
		return () => window.clearInterval(id);
	}, [freeze, reduced]);
	const visible = (0, import_react.useMemo)(() => {
		const n = Math.max(0, Math.min(count, SLOTS.length));
		return Array.from({ length: n }, (_, i) => {
			const photo = list[(tick + i) % list.length];
			return {
				photo,
				slot: SLOTS[(tick + i) % SLOTS.length],
				key: `${photo.src}-${i}-${tick}`
			};
		});
	}, [
		count,
		list,
		tick
	]);
	if (count <= 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("pointer-events-none absolute inset-0", className),
		"aria-hidden": true,
		children: visible.map(({ photo, slot, key }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Polaroid, {
			photo,
			slot
		}, key))
	});
}
function PoeticLetter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative mx-auto flex min-h-[100dvh] max-w-lg flex-col justify-center px-6 py-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-10 text-center text-[0.65rem] tracking-[0.42em] text-champagne uppercase",
			children: "a note"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-8",
			children: personalMessage.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-center text-2xl leading-snug text-ivory italic sm:text-3xl",
				children: line
			}, line))
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative mx-auto flex min-h-[100dvh] max-w-xl flex-col justify-center px-6 py-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display mb-10 text-2xl text-ivory italic",
				children: letter.greeting
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-7",
				children: letter.body.map((para) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[1.05rem] leading-[1.75] text-ivory-dim",
					children: para
				}, para))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display mt-14 text-2xl text-ivory italic",
				children: letter.signoff
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-sm tracking-[0.18em] text-muted",
				children: letter.closing
			})
		]
	})] });
}
function readPreview() {
	if (typeof window === "undefined") return null;
	const value = new URLSearchParams(window.location.search).get("preview");
	if (value === "opening" || value === "waiting" || value === "final10" || value === "zero" || value === "world") return value;
	return null;
}
function BirthdayWorld() {
	const reduced = usePrefersReducedMotion();
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [preview, setPreview] = (0, import_react.useState)(null);
	const [phase, setPhase] = (0, import_react.useState)("opening");
	const [lineVisible, setLineVisible] = (0, import_react.useState)(true);
	const clock = useCountdown((0, import_react.useMemo)(() => {
		if (preview === "final10") return 10500;
		if (preview === "waiting") return 2406e4;
		return null;
	}, [preview]));
	useLenis(phase === "world");
	(0, import_react.useEffect)(() => {
		setMounted(true);
		const next = readPreview();
		setPreview(next);
		if (next === "world") setPhase("world");
		if (next === "zero") setPhase("zero");
		if (next === "waiting") setPhase("waiting");
		if (next === "final10") setPhase("final10");
	}, []);
	(0, import_react.useEffect)(() => {
		if (preview === "waiting" || preview === "opening") return;
		if (phase === "opening" || phase === "zero" || phase === "world") return;
		if (clock.isZero) {
			setPhase("zero");
			return;
		}
		if (clock.totalSeconds <= 10 && phase === "waiting") setPhase("final10");
	}, [
		clock.isZero,
		clock.totalSeconds,
		phase,
		preview
	]);
	(0, import_react.useEffect)(() => {
		if (phase !== "waiting") return;
		const id = window.setTimeout(() => setLineVisible(false), 14e3);
		return () => window.clearTimeout(id);
	}, [phase]);
	const locked = phase !== "world";
	if (!mounted) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "h-[100dvh] bg-void",
		"aria-label": "For Srijoni"
	});
	const onOpeningDone = () => {
		if (preview === "opening") {
			setPhase("waiting");
			return;
		}
		if (preview === "final10") {
			setPhase("final10");
			return;
		}
		if (clock.isZero) setPhase("zero");
		else if (clock.totalSeconds <= 10) setPhase("final10");
		else setPhase("waiting");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: cn("relative bg-void text-ivory", locked ? "h-[100dvh] overflow-hidden" : "min-h-[100dvh] overflow-x-hidden"),
		style: {
			paddingTop: "env(safe-area-inset-top)",
			paddingBottom: "env(safe-area-inset-bottom)"
		},
		children: [
			phase === "opening" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OpeningScene, {
				alreadyHere: clock.isZero && preview !== "waiting" && preview !== "opening",
				reduced,
				onComplete: onOpeningDone
			}) : null,
			phase === "waiting" || phase === "final10" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-0 transition-[background] duration-1000",
						style: { background: `radial-gradient(ellipse at 50% 42%, rgba(232, 201, 160, ${.04 + clock.atmosphere.warmth * .12}) 0%, transparent 55%)` }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ParticleField, {
						density: 48 + Math.round(clock.atmosphere.warmth * 40),
						warmth: clock.atmosphere.warmth,
						reduced
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlowerField, {
						motion: clock.atmosphere.motion,
						extra: clock.atmosphere.level === "minute" || clock.atmosphere.level === "tenmin",
						reduced
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeddyBear, {
						motion: clock.atmosphere.motion,
						reduced
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoMemory, {
						count: clock.atmosphere.photoCount,
						reduced,
						freeze: phase === "final10"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "vignette absolute inset-0" }),
					phase === "waiting" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative z-10 flex h-full flex-col items-center justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CountdownClock, {
							days: clock.days,
							hours: clock.hours,
							minutes: clock.minutes,
							seconds: clock.seconds,
							line: lineVisible ? waitingLine : void 0
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalTen, {
						seconds: clock.seconds,
						reduced
					})
				]
			}) : null,
			phase === "zero" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BirthdayTransition, {
				reduced,
				onComplete: () => setPhase("world")
			}) : null,
			phase === "world" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ParticleField, {
						density: 36,
						warmth: .45,
						reduced
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlowerField, {
						motion: .4,
						extra: true,
						reduced
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "grain absolute inset-0 z-20 h-full" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "relative z-10 flex min-h-[100dvh] flex-col items-center justify-center px-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-6 text-[0.65rem] tracking-[0.42em] text-champagne uppercase",
								children: "September 30"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display max-w-sm text-center text-4xl text-ivory italic sm:text-5xl",
								children: "Happy Birthday, Srijoni."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-8 text-sm tracking-[0.22em] text-muted",
								children: "scroll when you're ready"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative z-10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemoryGallery, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PoeticLetter, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CakeScene, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinalScene, {})
						]
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "grain pointer-events-none fixed inset-0 z-30" })
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BirthdayWorld, {});
}
//#endregion
export { Home as component };
