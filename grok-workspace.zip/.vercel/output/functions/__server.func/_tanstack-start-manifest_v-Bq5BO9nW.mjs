//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bq5BO9nW.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-D08xTQ8s.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D08xTQ8s.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-D3-Y7yis.js"]
	}
} });
//#endregion
export { tsrStartManifest };
